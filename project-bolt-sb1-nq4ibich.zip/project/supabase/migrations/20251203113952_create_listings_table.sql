/*
  # Google Maps Listings Database Schema

  ## Overview
  This migration creates the database structure for storing scraped Google Maps business listings.

  ## New Tables
  
  ### `scraping_sessions`
  Tracks each scraping session initiated by the user
  - `id` (uuid, primary key) - Unique identifier for the session
  - `business_type` (text) - Type of business being searched (e.g., "restaurants", "hotels")
  - `location` (text) - Location being searched (city, country)
  - `status` (text) - Current status: "running", "paused", "completed", "failed"
  - `total_records` (integer) - Total number of records scraped in this session
  - `started_at` (timestamptz) - When the scraping session started
  - `completed_at` (timestamptz, nullable) - When the scraping session completed
  - `created_at` (timestamptz) - Record creation timestamp

  ### `listings`
  Stores individual business listings scraped from Google Maps
  - `id` (uuid, primary key) - Unique identifier for the listing
  - `session_id` (uuid, foreign key) - References the scraping session
  - `name` (text) - Business name
  - `description` (text, nullable) - Business description
  - `rating` (numeric, nullable) - Rating value (0-5)
  - `website` (text, nullable) - Business website URL
  - `address` (text, nullable) - Physical address
  - `phone` (text, nullable) - Phone number
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Enable RLS on both tables
  - Allow public read access (sales rep use case)
  - Allow public write access for inserting scraped data

  ## Notes
  - Uses numeric type for ratings to handle decimal values
  - All timestamps use timestamptz for timezone awareness
  - Foreign key ensures data integrity between sessions and listings
*/

CREATE TABLE IF NOT EXISTS scraping_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_type text NOT NULL,
  location text NOT NULL,
  status text NOT NULL DEFAULT 'running',
  total_records integer DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES scraping_sessions(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  rating numeric(2,1),
  website text,
  address text,
  phone text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listings_session_id ON listings(session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_status ON scraping_sessions(status);

ALTER TABLE scraping_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE listings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to sessions"
  ON scraping_sessions FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert to sessions"
  ON scraping_sessions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public update to sessions"
  ON scraping_sessions FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public read access to listings"
  ON listings FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert to listings"
  ON listings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public update to listings"
  ON listings FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete to listings"
  ON listings FOR DELETE
  USING (true);