import { supabase, Listing } from '../lib/supabase';

export class GoogleMapsScraper {
  private sessionId: string | null = null;
  private isRunning = false;
  private isPaused = false;
  private abortController: AbortController | null = null;

  async startSession(businessType: string, location: string): Promise<string> {
    const { data, error } = await supabase
      .from('scraping_sessions')
      .insert({
        business_type: businessType,
        location: location,
        status: 'running',
        total_records: 0,
      })
      .select()
      .single();

    if (error) throw error;

    this.sessionId = data.id;
    this.isRunning = true;
    this.isPaused = false;
    this.abortController = new AbortController();

    return data.id;
  }

  async scrapeListings(
    businessType: string,
    location: string,
    onProgress: (listing: Listing) => void
  ): Promise<void> {
    if (!this.sessionId) {
      throw new Error('Session not started');
    }

    const mockListings = this.generateMockListings(businessType, location);

    for (let i = 0; i < mockListings.length; i++) {
      if (this.abortController?.signal.aborted) {
        break;
      }

      while (this.isPaused) {
        await new Promise(resolve => setTimeout(resolve, 100));
        if (this.abortController?.signal.aborted) {
          break;
        }
      }

      if (this.abortController?.signal.aborted) {
        break;
      }

      await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 400));

      const listing = mockListings[i];
      const { data, error } = await supabase
        .from('listings')
        .insert({
          session_id: this.sessionId,
          name: listing.name,
          description: listing.description,
          rating: listing.rating,
          website: listing.website,
          address: listing.address,
          phone: listing.phone,
        })
        .select()
        .single();

      if (error) {
        console.error('Error inserting listing:', error);
        continue;
      }

      await supabase
        .from('scraping_sessions')
        .update({ total_records: i + 1 })
        .eq('id', this.sessionId);

      onProgress(data);
    }

    if (!this.abortController?.signal.aborted) {
      await this.completeSession();
    }
  }

  pause() {
    this.isPaused = true;
    if (this.sessionId) {
      supabase
        .from('scraping_sessions')
        .update({ status: 'paused' })
        .eq('id', this.sessionId);
    }
  }

  resume() {
    this.isPaused = false;
    if (this.sessionId) {
      supabase
        .from('scraping_sessions')
        .update({ status: 'running' })
        .eq('id', this.sessionId);
    }
  }

  stop() {
    this.abortController?.abort();
    this.isRunning = false;
    if (this.sessionId) {
      supabase
        .from('scraping_sessions')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', this.sessionId);
    }
  }

  private async completeSession() {
    if (this.sessionId) {
      await supabase
        .from('scraping_sessions')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', this.sessionId);
    }
    this.isRunning = false;
  }

  getIsPaused() {
    return this.isPaused;
  }

  getIsRunning() {
    return this.isRunning;
  }

  private generateMockListings(businessType: string, location: string) {
    const count = 15 + Math.floor(Math.random() * 10);
    const listings = [];

    const businessNames = [
      'Premium', 'Golden', 'Royal', 'Elite', 'Grand', 'Superior',
      'Modern', 'Classic', 'Urban', 'Downtown', 'Central', 'Main Street',
      'Park', 'Bay', 'Hill', 'Valley', 'Riverside', 'Lakeside'
    ];

    const businessSuffixes = [
      businessType.slice(0, -1),
      businessType,
      `${businessType} Co.`,
      `${businessType} Place`,
      `${businessType} Hub`,
      `${businessType} Center`
    ];

    for (let i = 0; i < count; i++) {
      const prefix = businessNames[Math.floor(Math.random() * businessNames.length)];
      const suffix = businessSuffixes[Math.floor(Math.random() * businessSuffixes.length)];
      const name = `${prefix} ${suffix}`;

      const rating = (3.5 + Math.random() * 1.5).toFixed(1);
      const streetNum = Math.floor(Math.random() * 9999) + 1;
      const streets = ['Main St', 'Oak Ave', 'Park Blvd', 'Broadway', 'Market St', 'First Ave'];
      const street = streets[Math.floor(Math.random() * streets.length)];

      listings.push({
        name,
        description: `A quality ${businessType.slice(0, -1)} serving ${location} with excellent service and professional staff.`,
        rating: parseFloat(rating),
        website: `https://www.${name.toLowerCase().replace(/\s+/g, '')}.com`,
        address: `${streetNum} ${street}, ${location}`,
        phone: `+1 (555) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
      });
    }

    return listings;
  }
}
