import { useState } from 'react';
import { SearchForm } from './components/SearchForm';
import { ProgressTracker } from './components/ProgressTracker';
import { DataTable } from './components/DataTable';
import { GoogleMapsScraper } from './services/scraper';
import { Listing } from './lib/supabase';
import { exportToCSV, exportToExcel } from './utils/exportUtils';
import { MapPin } from 'lucide-react';

function App() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [isScrapingActive, setIsScrapingActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [scraper] = useState(() => new GoogleMapsScraper());

  const handleStartScraping = async (businessType: string, location: string) => {
    setListings([]);
    setIsScrapingActive(true);
    setIsPaused(false);

    try {
      await scraper.startSession(businessType, location);

      scraper.scrapeListings(businessType, location, (newListing) => {
        setListings((prev) => [...prev, newListing]);
      }).then(() => {
        setIsScrapingActive(false);
      }).catch((error) => {
        console.error('Scraping error:', error);
        setIsScrapingActive(false);
      });
    } catch (error) {
      console.error('Failed to start session:', error);
      setIsScrapingActive(false);
    }
  };

  const handlePause = () => {
    scraper.pause();
    setIsPaused(true);
  };

  const handleResume = () => {
    scraper.resume();
    setIsPaused(false);
  };

  const handleStop = () => {
    scraper.stop();
    setIsScrapingActive(false);
    setIsPaused(false);
  };

  const handleExportCSV = () => {
    const timestamp = new Date().toISOString().split('T')[0];
    exportToCSV(listings, `google-maps-listings-${timestamp}.csv`);
  };

  const handleExportExcel = () => {
    const timestamp = new Date().toISOString().split('T')[0];
    exportToExcel(listings, `google-maps-listings-${timestamp}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <MapPin className="text-white" size={28} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Google Maps Scraper</h1>
              <p className="text-sm text-gray-600 mt-1">Sales Intelligence Tool</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-1">
            <SearchForm
              onStartScraping={handleStartScraping}
              isScrapingActive={isScrapingActive}
            />
          </div>

          <div className="lg:col-span-2">
            <ProgressTracker
              isScrapingActive={isScrapingActive}
              isPaused={isPaused}
              recordsScraped={listings.length}
              onPause={handlePause}
              onResume={handleResume}
              onStop={handleStop}
            />
          </div>
        </div>

        <DataTable
          listings={listings}
          onExportCSV={handleExportCSV}
          onExportExcel={handleExportExcel}
        />
      </main>
    </div>
  );
}

export default App;
